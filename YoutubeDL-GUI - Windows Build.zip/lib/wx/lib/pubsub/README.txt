Release Notes
=============

* cleanup low-level API: exception classes, moved some out of pub module that did not
  belong there (clutter), move couple modules, 
* completed the reference documentation
* support installation via pip
* follow some guidelines in some PEPs such as PEP 396 and PEP 8
* support Python 2.6, 2.7, and 3.2 to 3.4a4 but drop support for Python <= 2.5
